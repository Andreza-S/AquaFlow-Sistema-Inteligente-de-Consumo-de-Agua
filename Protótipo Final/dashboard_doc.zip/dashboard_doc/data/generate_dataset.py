import pandas as pd
import numpy as np
from pathlib import Path

OUT = Path(__file__).parent / 'data.csv'

def generate(
    start='2024-10-01',
    days=365,
    freq='15T',
    leak_prob=0.002,
    leak_min=0.2,
    leak_max=1.0
):
    """
    Gera dataset de consumo de água por 1 ano a cada 15 min, simulando vazamentos.
    """

    total_periods = int((24 * 60 / 15) * days)
    idx = pd.date_range(start=start, periods=total_periods, freq=freq)

    rows = []

    for ts in idx:
        h = ts.hour

        # Vazões individuais (L/s)
        s1 = s2 = s3 = 0.0

        # Máquina de lavar (S1)
        if 6 <= h <= 8 or 19 <= h <= 22:
            if np.random.rand() < 0.3:
                s1 = np.random.normal(0.8, 0.3)

        # Cozinha (S2)
        if 11 <= h <= 13 or 17 <= h <= 19:
            if np.random.rand() < 0.25:
                s2 = np.random.normal(0.6, 0.25)

        # Banheiro (S3)
        if (h == 5 or h == 18) and (ts.day % 2 == 0):
            s3 = np.random.normal(1.2, 0.4)

        # Ruído mínimo
        s1 = max(0, s1 + np.random.normal(0, 0.02))
        s2 = max(0, s2 + np.random.normal(0, 0.02))
        s3 = max(0, s3 + np.random.normal(0, 0.02))

        # Total (S4)
        s4 = s1 + s2 + s3

        # Vazamento
        if np.random.rand() < leak_prob:
            s4 += np.random.uniform(leak_min, leak_max)

        # Pulsos (10 pulsos por L/min)
        def pulses(lps):
            return int(lps * 60 * 10)

        rows.append({
            'Timestamp': ts,

            'S1 Pulsos': pulses(s1),
            'S1 L/s': round(s1, 4),

            'S2 Pulsos': pulses(s2),
            'S2 L/s': round(s2, 4),

            'S3 Pulsos': pulses(s3),
            'S3 L/s': round(s3, 4),

            'S4 Pulsos': pulses(s4),
            'S4 L/s': round(s4, 4),
        })

    df = pd.DataFrame(rows)
    df.to_csv(OUT, index=False)
    print(f'Dataset gerado em {OUT} | linhas: {len(df)}')

if __name__ == '__main__':
    generate()
