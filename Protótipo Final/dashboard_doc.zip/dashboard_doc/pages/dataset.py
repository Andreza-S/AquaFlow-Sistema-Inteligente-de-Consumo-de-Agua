from dash import html, dcc, dash_table, Input, Output, State
import pandas as pd

def layout(DATA_PATH):
    """
    Cria o layout da página Dataset.

    Parâmetros:
    - DATA_PATH: caminho do CSV com os dados

    Retorna:
    - Div contendo tabela interativa com leitura em tempo real do CSV
    """
    return html.Div([

        html.H3("Leitura em Tempo Real do CSV"),

        # Guarda o caminho do CSV para uso no callback
        dcc.Store(id="dataset-path-store", data=str(DATA_PATH)),

        # Intervalo para atualizar a tabela a cada 1 segundo
        dcc.Interval(
            id="dataset-interval-csv",
            interval=1000,  # 1 segundo
            n_intervals=0
        ),

        # Tabela interativa
        dash_table.DataTable(
            id="dataset-table",
            columns=[],  # será preenchido dinamicamente
            data=[],
            page_size=15,
            style_table={"overflowX": "auto"},
            style_cell={"textAlign": "center"}
        )
    ])


def register_callbacks(app):
    """
    Registra os callbacks da página Dataset no app Dash.
    """

    @app.callback(
        Output("dataset-table", "data"),
        Output("dataset-table", "columns"),
        Input("dataset-interval-csv", "n_intervals"),
        State("dataset-path-store", "data"),
        prevent_initial_call=False
    )
    def update_table(_, data_path):
        """
        Atualiza a tabela a cada intervalo definido.

        - Lê o CSV no caminho armazenado;
        - Exibe as linhas mais recentes primeiro;
        - Atualiza colunas dinamicamente.
        """
        if not data_path:
            return [], []

        try:
            df = pd.read_csv(data_path)
        except Exception as e:
            print("Erro ao ler CSV:", e)
            return [], []

        # Mais recentes primeiro
        df = df.iloc[::-1].reset_index(drop=True)

        return (
            df.to_dict("records"),
            [{"name": c, "id": c} for c in df.columns]
        )
