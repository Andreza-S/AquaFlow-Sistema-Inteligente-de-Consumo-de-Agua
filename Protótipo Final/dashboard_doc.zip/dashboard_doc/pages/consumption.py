from dash import html, dcc, Input, Output, callback
import pandas as pd
import plotly.express as px
from pathlib import Path
import json

# Arquivo de configuração
CONFIG_FILE = Path(__file__).parent.parent / "data" / "config.json"

# Colunas do CSV referentes aos sensores
sensor_cols = ['S1 L/s', 'S2 L/s', 'S3 L/s', 'S4 L/s']


def layout(data_path):
    """
    Cria o layout da página Consumo.

    Parâmetros:
    - data_path: caminho do CSV com os dados de consumo

    Retorna:
    - Div contendo Dropdown de seleção de mês e gráficos de consumo (mês, semana e dia)
    """
    return html.Div([
        html.H3('Consumo - Gráficos'),

        html.Label('Escolha o mês:'),
        dcc.Dropdown(
            id='cons-month',
            options=[
                {'label': m, 'value': i}
                for i, m in enumerate(
                    ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                     'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'], 1
                )
            ],
            value=1
        ),

        dcc.Tabs(id='cons-tabs', children=[
            dcc.Tab(label='Mês', children=[dcc.Graph(id='cons-graph-month')]),
            dcc.Tab(label='Semana', children=[dcc.Graph(id='cons-graph-week')]),
            dcc.Tab(label='Dia', children=[dcc.Graph(id='cons-graph-day')]),
        ]),

        # Armazena o caminho do CSV para o callback
        dcc.Store(id='cons-store-path', data=str(data_path))
    ])


@callback(
    Output('cons-graph-month', 'figure'),
    Output('cons-graph-week', 'figure'),
    Output('cons-graph-day', 'figure'),
    Input('cons-month', 'value'),
    Input('cons-store-path', 'data')
)
def update_graphs(selected_month, data_path):
    """
    Atualiza os gráficos de consumo conforme o mês selecionado.

    Passos principais:
    1. Ler CSV e verificar existência;
    2. Obter nomes configurados para os sensores via config.json;
    3. Converter coluna Timestamp para datetime;
    4. Criar DataFrame de consumo alinhado;
    5. Calcular consumo médio mensal;
    6. Filtrar dados do mês selecionado;
    7. Calcular consumo diário;
    8. Calcular consumo semanal.
    """
    data_path = Path(data_path)

    if not data_path.exists():
        empty = px.scatter(title="Sem dados disponíveis")
        return empty, empty, empty

    df = pd.read_csv(data_path)
    if df.empty:
        empty = px.scatter(title="Sem dados disponíveis")
        return empty, empty, empty

    # Obter nomes configurados dos sensores
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            config = json.load(f)
        sensor_names = [
            config.get("sensors", {}).get(col, col)
            for col in sensor_cols
        ]
    else:
        sensor_names = sensor_cols

    # Garantir Timestamp
    df['Timestamp'] = pd.to_datetime(df['Timestamp'], errors='coerce')
    df = df.dropna(subset=['Timestamp'])
    df = df.set_index('Timestamp')

    # Criar DataFrame de consumo alinhado
    df_vol = pd.DataFrame(index=df.index)
    for col, name in zip(sensor_cols, sensor_names):
        df_vol[name] = df[col] if col in df.columns else 0.0

    # Consumo médio mensal
    monthly = df_vol.resample('ME').mean()
    monthly_plot = monthly.copy()
    monthly_plot["Mes"] = monthly_plot.index.strftime('%b %Y')

    fig_m = px.bar(
        monthly_plot,
        x="Mes",
        y=sensor_names,
        barmode='group',
        title="Consumo médio mensal"
    )

    # Filtrar dados do mês selecionado
    df_month = df_vol[df_vol.index.month == selected_month]
    if df_month.empty:
        empty = px.scatter(title="Sem dados para este mês")
        return fig_m, empty, empty

    # Consumo diário
    daily = df_month.resample('D').sum()
    daily_plot = daily.copy()
    daily_plot["Dia"] = daily_plot.index.day

    fig_d = px.bar(
        daily_plot,
        x="Dia",
        y=sensor_names,
        title=f"Consumo diário - mês {selected_month}",
        barmode='group'
    )

    # Consumo semanal
    weekly = df_month.resample('W-SUN').sum()
    weekly_plot = weekly.copy()
    weekly_plot["Semana"] = weekly_plot.index.isocalendar().week

    fig_w = px.bar(
        weekly_plot,
        x="Semana",
        y=sensor_names,
        title=f"Consumo semanal - mês {selected_month}",
        barmode='group'
    )

    return fig_m, fig_w, fig_d
