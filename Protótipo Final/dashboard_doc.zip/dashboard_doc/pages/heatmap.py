import base64
import json
from pathlib import Path
from dash import html, dcc, Output, Input, State, callback
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from pandas.errors import EmptyDataError

# Diretórios principais
ROOT_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = ROOT_DIR / 'data' / 'config.json'
DATA_FILE = ROOT_DIR / 'data' / 'data_test.csv'  # Dados em tempo real
ASSETS_DIR = ROOT_DIR / 'assets'

# Coordenadas padrão para cada sensor na planta da casa
DEFAULT_LAYOUT = {
    'S1 L/s': {'label': 'Sensor 1', 'x': 0.8, 'y': 0.8},
    'S2 L/s': {'label': 'Sensor 2', 'x': 0.1, 'y': 0.48},
    'S3 L/s': {'label': 'Sensor 3', 'x': 0.85, 'y': 0.6},
    'S4 L/s': {'label': 'Sensor 4', 'x': 0.58, 'y': 0.05},
}

def load_config():
    """Carrega o arquivo config.json e retorna como dict."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"sensors": {}, "sensor_positions": {}}

def save_config(config):
    """Salva o dict de configuração no arquivo config.json."""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

def layout(data_path):
    """
    Cria o layout da página Mapa de Calor.
    
    Parâmetros:
    - data_path: caminho do CSV de dados (não utilizado diretamente, pois DATA_FILE já é data_test.csv)

    Retorna:
    - Div contendo o gráfico interativo e painel de edição de sensores
    """
    return html.Div([
        html.H3("Mapa de Calor - Planta da Casa", className="text-center mb-2"),
        html.P("Clique em um sensor para mover e atualizar sua posição.",
               className="text-center text-muted mb-4"),

        dcc.Graph(id='heatmap-graph', style={'height': '80vh'}),
        dcc.Interval(id='interval-home', interval=1000, n_intervals=0),  # Atualização a cada 1s

        # Painel de edição das posições dos sensores
        html.Div(id="edit-panel", style={'marginTop': '20px', 'display': 'none'}, children=[
            html.H5("Editar Posição do Sensor"),
            html.Div(id="selected-sensor", className="fw-bold"),
            html.Div([
                html.Label("Nova posição X:"),
                dcc.Input(id="input-x", type="number", step=0.01, min=0, max=1),
                html.Label("Nova posição Y:", style={'marginLeft': '15px'}),
                dcc.Input(id="input-y", type="number", step=0.01, min=0, max=1),
                html.Button("Salvar posição", id="btn-save", n_clicks=0, className="btn btn-primary ms-3")
            ], className="mt-2"),
        ])
    ])


# === CALLBACKS ===

@callback(
    Output('heatmap-graph', 'figure'),
    Input('interval-home', 'n_intervals')
)
def update_heatmap(_):
    """
    Atualiza o Mapa de Calor a cada intervalo definido.
    
    - Lê os dados do CSV;
    - Atualiza a posição, tamanho e cor dos sensores com base no consumo;
    - Desenha a planta da casa como background (imagem).
    """
    config = load_config()
    sensor_names = config.get("sensors", {})
    sensor_positions = config.get("sensor_positions", {})

    # Ler CSV com tratamento de erros
    df = None
    try:
        df = pd.read_csv(DATA_FILE)
        if df is None or df.empty or len(df.columns) == 0:
            df = None
    except (FileNotFoundError, EmptyDataError, pd.errors.ParserError):
        df = None
    except Exception:
        df = None

    # Construção das listas para o gráfico
    sensor_keys = list(DEFAULT_LAYOUT.keys())
    xs, ys, labels, vals = [], [], [], []

    if df is None:  # sem dados
        for s in sensor_keys:
            base = sensor_positions.get(s) or DEFAULT_LAYOUT.get(s)
            if base is None:
                base = {'label': s, 'x': 0.5, 'y': 0.5}
            label = sensor_names.get(s, base['label'])
            xs.append(base['x']); ys.append(base['y']); labels.append(label); vals.append(0.0)
    else:
        # Dados disponíveis: usar última linha
        if 'Timestamp' in df.columns:
            try:
                df['Timestamp'] = pd.to_datetime(df['Timestamp'], errors='coerce')
            except Exception:
                pass
        last_row = df.iloc[-1] if not df.empty else None
        for s in sensor_keys:
            base = sensor_positions.get(s) or DEFAULT_LAYOUT.get(s)
            if base is None:
                base = {'label': s, 'x': 0.5, 'y': 0.5}
            label = sensor_names.get(s, base['label'])
            val = 0.0
            if last_row is not None and s in df.columns:
                try:
                    v = last_row[s]
                    val = float(v) if pd.notna(v) else 0.0
                except Exception:
                    val = 0.0
            xs.append(base['x']); ys.append(base['y']); labels.append(label); vals.append(val)

    vals = np.array(vals, dtype=float)

    # Normalização de cores
    if vals.size == 0:
        vals_norm = np.array([])
    else:
        vmin = vals.min()
        vmax = vals.max()
        vals_norm = np.zeros_like(vals) if vmax - vmin <= 1e-9 else (vals - vmin) / (vmax - vmin)

    # Definir tamanhos das bolinhas
    if vals.size == 0:
        marker_sizes = np.array([])
    else:
        vmin = vals.min()
        vmax = vals.max()
        if vmax - vmin <= 1e-9:
            marker_sizes = np.full_like(vals, 18.0 if vmax == 0 else 40.0)
        else:
            marker_sizes = np.interp(vals, (vmin, vmax), (20, 80))

    # Carregar imagem da planta
    img_path = ASSETS_DIR / 'house.png'
    img_src = None
    if img_path.exists():
        try:
            encoded = base64.b64encode(open(img_path, 'rb').read()).decode()
            img_src = f"data:image/png;base64,{encoded}"
        except Exception:
            img_src = None

    # Montar figura
    fig = go.Figure()
    if img_src:
        fig.add_layout_image(
            dict(source=img_src, xref="x", yref="y", x=0, y=1, sizex=1, sizey=1,
                 sizing="stretch", opacity=1, layer="below")
        )

    # Adicionar marcadores
    if len(xs) == 0:
        fig.add_annotation(text="Sem sensores configurados", x=0.5, y=0.5, showarrow=False)
        fig.update_layout(template='plotly_white', xaxis_visible=False, yaxis_visible=False)
        return fig

    marker_kwargs = {'size': marker_sizes, 'color': vals_norm,
                     'colorscale': 'YlOrRd', 'showscale': True,
                     'colorbar': dict(title='Intensidade (normalizada)')}

    hover_temps = [f"<b>{lab}</b><br>Vazão: {v:.3f} L/s" for lab, v in zip(labels, vals)]
    fig.add_trace(go.Scatter(x=xs, y=ys, mode='markers+text', text=labels,
                             textposition='top center', marker=marker_kwargs,
                             hoverinfo='text', hovertext=hover_temps))

    fig.update_xaxes(visible=False, range=[0, 1])
    fig.update_yaxes(visible=False, range=[0, 1], scaleanchor="x", scaleratio=1)
    fig.update_layout(margin=dict(l=20, r=20, t=40, b=20), template='plotly_white')

    return fig


# === Interação de edição dos sensores ===

@callback(
    Output("edit-panel", "style"),
    Output("selected-sensor", "children"),
    Output("input-x", "value"),
    Output("input-y", "value"),
    Input("heatmap-graph", "clickData")
)
def select_sensor(click_data):
    """
    Ao clicar no sensor, exibe painel de edição com coordenadas atuais.
    """
    if not click_data or "points" not in click_data or not click_data["points"]:
        return {'display': 'none'}, "", None, None

    point = click_data["points"][0]
    label = point["text"]
    x = round(point["x"], 2)
    y = round(point["y"], 2)
    return {'display': 'block'}, f"Sensor selecionado: {label}", x, y


@callback(
    Output("edit-panel", "style", allow_duplicate=True),
    Input("btn-save", "n_clicks"),
    State("selected-sensor", "children"),
    State("input-x", "value"),
    State("input-y", "value"),
    prevent_initial_call=True
)
def save_position(n_clicks, label_text, new_x, new_y):
    """
    Salva a nova posição do sensor no config.json após edição.
    """
    if not n_clicks or not label_text:
        return {'display': 'none'}
    if new_x is None or new_y is None:
        return {'display': 'none'}

    sensor_label = label_text.replace("Sensor selecionado: ", "")

    CONFIG_FILE.parent.mkdir(exist_ok=True)
    config = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            config = json.load(f)

    sensor_positions = config.get("sensor_positions", {})
    sensors = config.get("sensors", {})
    sensor_key = None
    for key, name in sensors.items():
        if name == sensor_label:
            sensor_key = key
            break
    if not sensor_key:
        print(f"Aviso: sensor '{sensor_label}' não encontrado em config['sensors']")
        return {'display': 'none'}

    sensor_positions[sensor_key] = {'x': new_x, 'y': new_y}
    config['sensor_positions'] = sensor_positions

    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)

    print(f"Sensor '{sensor_label}' atualizado: x={new_x}, y={new_y}")
    return {'display': 'none'}
