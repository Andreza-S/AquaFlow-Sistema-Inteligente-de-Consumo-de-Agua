from dash import html, dcc, Input, Output
import dash
import plotly.express as px
import pandas as pd

def layout(app, data_path):
    """
    Cria o layout da página de sensores e registra os callbacks
    responsáveis pela atualização dos gráficos.

    Parâmetros:
    - app: instância principal da aplicação Dash
    - data_path: caminho para o arquivo CSV contendo os dados dos sensores

    Retorno:
    - Div contendo os gráficos individuais de cada sensor
    """

    # Leitura do dataset, caso o arquivo exista
    df = pd.read_csv(data_path) if pd.io.common.file_exists(data_path) else pd.DataFrame()

    # Identificação das colunas referentes aos sensores (ex: S1, S2, S3...)
    sensor_cols = [c for c in df.columns if c.startswith('S')]

    # Criação de um gráfico para cada sensor identificado
    graphs = [dcc.Graph(id=f'graph-{s}') for s in sensor_cols]

    # Layout da página
    layout_div = html.Div(
        [html.H3('Métricas por Torneira')] + graphs
    )

    # Callback responsável por atualizar todos os gráficos simultaneamente
    @app.callback(
        [Output(f'graph-{s}', 'figure') for s in sensor_cols],
        Input(f'graph-{sensor_cols[0]}', 'id')  # trigger inicial
    )
    def update_sensors(_):
        """
        Atualiza os gráficos de consumo diário para cada sensor.
        """

        # Caso não existam dados disponíveis
        if df.empty:
            return [px.scatter().update_layout(title='Sem dados')] * len(sensor_cols)

        # Conversão do timestamp e definição como índice
        df2 = df.copy()
        df2['Timestamp'] = pd.to_datetime(df2['Timestamp'])
        df2 = df2.set_index('Timestamp')

        figs = []

        # Geração dos gráficos individuais por sensor
        for s in sensor_cols:
            ser = df2[s].resample('D').sum()
            figs.append(
                px.line(
                    ser.reset_index(),
                    x='Timestamp',
                    y=s,
                    title=f'Consumo diário - {s}'
                )
            )

        return figs

    return layout_div