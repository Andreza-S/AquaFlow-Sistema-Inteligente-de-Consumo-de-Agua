from dash import html, dcc, Output, Input, callback
import pandas as pd
import plotly.graph_objects as go
import numpy as np
import json
from pathlib import Path
import dash_bootstrap_components as dbc
import pickle

# Caminho para o arquivo de configuração
CONFIG_FILE = Path(__file__).parent.parent / 'data' / 'config.json'

# Diretório onde os modelos treinados estão armazenados
MODEL_DIR = Path(__file__).parent.parent / "ml" / "models"


def layout(data_path):
    """
    Define o layout da página de previsão de consumo.

    Parâmetros:
    - data_path: caminho para o arquivo CSV utilizado na previsão

    Retorno:
    - Layout HTML da página
    """
    return html.Div([
        html.H3("Previsão de Gastos", className="text-center mb-3"),
        html.P(
            "Projeção de consumo de água e custo para o próximo mês, com base nos últimos registros.",
            className="text-center text-muted mb-4"
        ),

        # Armazena o caminho do CSV para uso nos callbacks
        dcc.Store(id="pred-store-path", data=str(data_path)),

        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardBody([
                    html.H5("Consumo do último mês (L)", className="text-muted"),
                    html.H3(id="last-month", className="fw-bold")
                ])
            ], className="shadow-sm"), width=3),

            dbc.Col(dbc.Card([
                dbc.CardBody([
                    html.H5("Previsão do próximo mês (L)", className="text-muted"),
                    html.H3(id="predicted-month", className="fw-bold text-primary")
                ])
            ], className="shadow-sm"), width=3),

            dbc.Col(dbc.Card([
                dbc.CardBody([
                    html.H5("Variação estimada (%)", className="text-muted"),
                    html.H3(id="variation", className="fw-bold")
                ])
            ], className="shadow-sm"), width=3),

            dbc.Col(dbc.Card([
                dbc.CardBody([
                    html.H5("Custo estimado (R$)", className="text-muted"),
                    html.H3(id="predicted-cost", className="fw-bold text-success")
                ])
            ], className="shadow-sm"), width=3),
        ], className="mb-4 text-center"),

        dcc.Graph(id="pred-graph", style={"height": "70vh"})
    ], className="p-4")


@callback(
    Output("pred-graph", "figure"),
    Output("last-month", "children"),
    Output("predicted-month", "children"),
    Output("variation", "children"),
    Output("predicted-cost", "children"),
    Input("pred-store-path", "data")
)
def update_pred(data_path):
    """
    Executa o processamento dos dados, realiza a previsão
    e atualiza os indicadores e o gráfico da página.
    """

    data_path = Path(data_path)

    # ===============================
    # 1) Leitura do CSV
    # ===============================
    if not data_path.exists():
        fig = go.Figure()
        fig.add_annotation(text="Sem dados disponíveis", x=0.5, y=0.5, showarrow=False)
        return fig, "-", "-", "-", "-"

    df = pd.read_csv(data_path)

    required_cols = ['Timestamp', 'S1 L/s', 'S2 L/s', 'S3 L/s', 'S4 L/s']
    if not all(col in df.columns for col in required_cols):
        fig = go.Figure()
        fig.add_annotation(text="Formato de dados incompatível", x=0.5, y=0.5, showarrow=False)
        return fig, "-", "-", "-", "-"

    df['Timestamp'] = pd.to_datetime(df['Timestamp'], errors='coerce')
    df = df.dropna(subset=['Timestamp'])
    df = df.set_index('Timestamp')

    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="Sem dados disponíveis", x=0.5, y=0.5, showarrow=False)
        return fig, "-", "-", "-", "-"

    # ===============================
    # 2) Cálculo do total de litros
    #    (L/s * 900s = intervalo de 15 minutos)
    # ===============================
    df['Total_L'] = df[['S1 L/s', 'S2 L/s', 'S3 L/s', 'S4 L/s']].sum(axis=1) * 900

    # ===============================
    # 3) Agregação mensal
    # ===============================
    monthly = df['Total_L'].resample('ME').sum().reset_index()
    monthly['month_idx'] = np.arange(len(monthly))

    if len(monthly) < 3:
        fig = go.Figure()
        fig.add_annotation(
            text="Dados insuficientes para previsão",
            x=0.5, y=0.5, showarrow=False
        )
        return fig, "-", "-", "-", "-"

    # ===============================
    # 4) Carregamento do modelo
    # ===============================
    model = pickle.load(open(MODEL_DIR / "best_model.pkl", "rb"))
    scaler = pickle.load(open(MODEL_DIR / "scaler.pkl", "rb"))

    # Previsão do próximo mês
    next_idx = monthly['month_idx'].iloc[-1] + 1
    next_idx_scaled = scaler.transform([[next_idx]])
    pred = model.predict(next_idx_scaled)[0]

    # Último valor real observado
    last_val = monthly['Total_L'].iloc[-1]

    variation = ((pred - last_val) / last_val) * 100 if last_val > 0 else 0

    # ===============================
    # 5) Estimativa de custo
    # ===============================
    water_price = 5.0
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            config = json.load(f)
        water_price = config.get("water_price", 5.0)

    pred_cost = (pred / 1000) * water_price

    # ===============================
    # 6) Construção do gráfico
    # ===============================
    fig = go.Figure()

    fig.add_trace(go.Bar(
        x=monthly['Timestamp'],
        y=monthly['Total_L'],
        name="Histórico"
    ))

    X_scaled = scaler.transform(monthly[['month_idx']])
    trend = model.predict(X_scaled)

    fig.add_trace(go.Scatter(
        x=monthly['Timestamp'],
        y=trend,
        mode="lines",
        name="Tendência (IA)",
        line=dict(dash="dash")
    ))

    fig.add_trace(go.Bar(
        x=[monthly['Timestamp'].max() + pd.offsets.MonthBegin(1)],
        y=[pred],
        name="Previsto (IA)"
    ))

    fig.update_layout(
        title="Projeção de Consumo Mensal (IA)",
        xaxis_title="Mês",
        yaxis_title="Consumo (Litros)",
        template="plotly_white",
        legend=dict(orientation="h", y=-0.25)
    )

    return (
        fig,
        f"{last_val:,.0f}",
        f"{pred:,.0f}",
        f"{variation:+.1f}%",
        f"R$ {pred_cost:,.2f}"
    )
