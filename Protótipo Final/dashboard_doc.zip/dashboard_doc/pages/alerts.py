from dash import html, dcc, Output, Input, dash_table, callback
import pandas as pd
import plotly.express as px
from pathlib import Path


# =========================================================
# DETECÇÃO DE VAZAMENTO (SEM SENSOR NA VÁLVULA)
# =========================================================
def detect_leak(df, min_diff=0.05):
    """
    Detecta vazamentos baseado na diferença entre vazão total (S4)
    e soma das vazões individuais (S1+S2+S3).

    Parâmetros:
    - df: DataFrame contendo os dados do CSV
    - min_diff: limiar mínimo para gerar alerta (L/s)

    Retorna:
    - DataFrame filtrado com os alertas detectados
    """
    if df.empty:
        return pd.DataFrame()

    # Garantir Timestamp
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])

    # Colunas obrigatórias
    required_cols = ['S1 L/s', 'S2 L/s', 'S3 L/s', 'S4 L/s']
    if not all(col in df.columns for col in required_cols):
        return pd.DataFrame()

    # Soma dos sensores individuais
    df['soma_sensores'] = df['S1 L/s'] + df['S2 L/s'] + df['S3 L/s']

    # Diferença entre total e soma
    df['diff'] = df['S4 L/s'] - df['soma_sensores']

    # Vazamento estimado (não negativo)
    df['vazamento_est'] = df['diff'].clip(lower=0)

    # Percentual excedente
    df['percentual'] = (
        (df['vazamento_est'] / df['S4 L/s'].replace(0, pd.NA)) * 100
    ).fillna(0).round(2)

    # Filtra alertas acima do limiar
    alerts = df[df['vazamento_est'] > min_diff]

    return alerts[
        [
            'Timestamp',
            'S4 L/s',
            'soma_sensores',
            'diff',
            'vazamento_est',
            'percentual'
        ]
    ]


# =========================================================
# LAYOUT
# =========================================================
def layout(data_path):
    """
    Layout da página de alertas de vazamento.

    Parâmetros:
    - data_path: caminho do CSV com os dados

    Retorna:
    - Div contendo gráfico, tabela e indicadores de alertas
    """
    return html.Div([

        html.H3("Alertas de Vazamento"),
        html.P(
            "Vazamentos são detectados quando a vazão total (S4) "
            "excede a soma dos sensores individuais."
        ),
        html.Hr(),

        html.Div(
            id="alert-status",
            style={
                "fontWeight": "bold",
                "color": "#004085",
                "marginBottom": "10px"
            }
        ),

        dcc.Graph(id="alert-graph"),
        html.Hr(),

        html.H5("Tabela de Alertas Detalhada"),

        dash_table.DataTable(
            id="alert-table",
            columns=[
                {"name": "Timestamp", "id": "Timestamp"},
                {"name": "Total (S4 – L/s)", "id": "S4 L/s"},
                {"name": "Soma Sensores (L/s)", "id": "soma_sensores"},
                {"name": "Diferença (L/s)", "id": "diff"},
                {"name": "Vazamento Estimado (L/s)", "id": "vazamento_est"},
                {"name": "Percentual Excedente (%)", "id": "percentual"},
            ],
            page_size=10,
            style_table={'overflowX': 'auto'},
            style_cell={'textAlign': 'center', 'fontFamily': 'sans-serif'},

            # Cores condicionais de acordo com intensidade do vazamento
            style_data_conditional=[
                {
                    'if': {'filter_query': '{diff} > 0.5'},
                    'backgroundColor': '#f8d7da',
                    'color': 'darkred',
                    'fontWeight': 'bold'
                },
                {
                    'if': {'filter_query': '{diff} <= 0.5 && {diff} > 0.15'},
                    'backgroundColor': '#fff3cd',
                    'color': '#856404',
                    'fontWeight': 'bold'
                },
                {
                    'if': {'filter_query': '{diff} <= 0.15 && {diff} > 0.05'},
                    'backgroundColor': '#d1ecf1',
                    'color': '#0c5460'
                }
            ]
        ),

        # Contador de eventos
        html.Div(
            id="alert-count",
            style={"marginTop": "10px", "fontWeight": "bold", "color": "#333"}
        ),

        # Guarda caminho do CSV
        dcc.Store(id="alerts-store-path", data=str(data_path)),

        # Atualização em tempo real
        dcc.Interval(id="interval-alerts", interval=1000, n_intervals=0)
    ])


# =========================================================
# CALLBACK
# =========================================================
@callback(
    Output("alert-graph", "figure"),
    Output("alert-table", "data"),
    Output("alert-status", "children"),
    Output("alert-count", "children"),
    Input("interval-alerts", "n_intervals"),
    Input("alerts-store-path", "data")
)
def update_alerts(_, data_path):
    """
    Atualiza os alertas em tempo real.

    Passos:
    1. Ler CSV;
    2. Detectar vazamentos usando detect_leak();
    3. Atualizar gráfico, tabela e indicadores.
    """
    data_path = Path(data_path)

    if not data_path.exists():
        return (
            px.line(title="Sem dados"),
            [],
            "Nenhum dado encontrado.",
            "Total de eventos detectados: 0"
        )

    df = pd.read_csv(data_path)

    # Mais recente primeiro
    df = df.iloc[::-1].reset_index(drop=True)

    alerts = detect_leak(df)

    if alerts.empty:
        return (
            px.line(title="Sistema normal – sem vazamentos."),
            [],
            "Nenhum vazamento detectado no momento.",
            "Total de eventos detectados: 0"
        )

    # Gráfico de dispersão dos vazamentos detectados
    fig = px.scatter(
        alerts,
        x="Timestamp",
        y="vazamento_est",
        color="vazamento_est",
        size="vazamento_est",
        title="⚠ Vazamentos detectados",
        labels={"vazamento_est": "Vazamento estimado (L/s)"}
    )

    status = (
        f"{len(alerts)} eventos detectados | "
        f"Último: {alerts['Timestamp'].max()}"
    )

    return (
        fig,
        alerts.to_dict("records"),
        status,
        f"Total de eventos detectados: {len(alerts)}"
    )
