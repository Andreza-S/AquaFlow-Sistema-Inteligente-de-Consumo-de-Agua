from dash import html, dcc, Input, Output, State, callback
import dash_bootstrap_components as dbc
import json
from pathlib import Path
import base64

# Caminho do arquivo de configuração
CONFIG_FILE = Path(__file__).parent.parent / 'data' / 'config.json'

# Diretório de assets (imagens, ícones)
ASSETS_PATH = Path(__file__).parent.parent / 'assets'
HOUSE_IMG = ASSETS_PATH / 'house.png'


def layout(data_path=None):
    """
    Define o layout da página Home (Configurações da Casa)

    Parâmetros:
    - data_path: opcional, não utilizado nesta página, presente por compatibilidade com a estrutura

    Retorno:
    - Div contendo a interface de configuração da casa e sensores
    """

    # Leitura do arquivo config.json, caso exista
    config = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)

    # Informações gerais
    owner = config.get("owner", "")
    address = config.get("address", "")
    water_price = config.get("water_price", 0)

    # Sensores
    sensors = config.get("sensors", {})
    s1 = sensors.get("S1 – Vazão (L/s)", "Sensor 1")
    s2 = sensors.get("S2 – Vazão (L/s)", "Sensor 2")
    s3 = sensors.get("S3- Vazão (L/s)", "Sensor 3")
    s4 = sensors.get("S4 – Vazão (L/s)", "Sensor 4")

    # Preview da imagem da casa
    if HOUSE_IMG.exists():
        encoded_image = base64.b64encode(HOUSE_IMG.read_bytes()).decode()
        house_preview = html.Img(
            src=f"data:image/png;base64,{encoded_image}",
            style={"maxWidth": "100%", "height": "auto", "border": "1px solid #ccc"}
        )
    else:
        house_preview = html.Div()

    # Layout principal
    return html.Div([
        html.H3("Configurações da Casa - AquaFlow", className="text-center mb-4"),
        html.P("Personalize os sensores, informações gerais e planta da casa.",
               className="text-center text-muted mb-4"),

        dbc.Row([
            # Coluna de Informações Gerais
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("Informações Gerais"),
                    dbc.CardBody([
                        html.Label("Nome do Proprietário"),
                        dbc.Input(id="input-owner", type="text", value=owner, className="mb-2"),

                        html.Label("Endereço da Casa"),
                        dbc.Input(id="input-address", type="text", value=address, className="mb-2"),

                        html.Label("Preço da Água (R$/m³)"),
                        dbc.Input(id="input-water-price", type="number", value=water_price, className="mb-2"),

                        html.Label("Planta da Casa"),
                        dcc.Upload(
                            id='upload-house',
                            children=html.Div(['Arraste ou clique para selecionar a imagem']),
                            style={
                                'width': '100%',
                                'height': '60px',
                                'lineHeight': '60px',
                                'borderWidth': '1px',
                                'borderStyle': 'dashed',
                                'borderRadius': '5px',
                                'textAlign': 'center',
                                'marginBottom': '10px'
                            },
                            accept='image/*',
                            multiple=False
                        ),
                        html.Div(house_preview, id='house-preview'),

                        dbc.Button("Salvar Configurações", id="btn-save-config",
                                   color="primary", className="mt-2 w-100"),
                        html.Div(id="save-msg", className="mt-2 text-success fw-bold")
                    ])
                ], className="mb-4 shadow-sm")
            ], width=5),

            # Coluna de Sensores
            dbc.Col([
                dbc.Card([
                    dbc.CardHeader("Sensores da Casa"),
                    dbc.CardBody([
                        html.Label("Sensor 1"),
                        dbc.Input(id="sensor-1", value=s1, className="mb-2"),

                        html.Label("Sensor 2"),
                        dbc.Input(id="sensor-2", value=s2, className="mb-2"),

                        html.Label("Sensor 3"),
                        dbc.Input(id="sensor-3", value=s3, className="mb-2"),

                        html.Label("Sensor 4"),
                        dbc.Input(id="sensor-4", value=s4, className="mb-2"),

                        dbc.Button("Salvar Sensores", id="btn-save-sensors",
                                   color="secondary", className="mt-2 w-100"),
                        html.Div(id="save-sensors-msg", className="mt-2 text-success fw-bold")
                    ])
                ], className="shadow-sm")
            ], width=7)
        ]),
    ], className="p-4")


# === CALLBACKS ===

@callback(
    Output("save-msg", "children"),
    Input("btn-save-config", "n_clicks"),
    State("input-owner", "value"),
    State("input-address", "value"),
    State("input-water-price", "value"),
    prevent_initial_call=True
)
def save_general_config(n, owner, address, price):
    """
    Salva as informações gerais da casa no arquivo config.json
    """
    CONFIG_FILE.parent.mkdir(exist_ok=True)
    config = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)

    config.update({
        "owner": owner or "",
        "address": address or "",
        "water_price": price or 0
    })

    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)
    return "✅ Configurações salvas com sucesso!"


@callback(
    Output("save-sensors-msg", "children"),
    Input("btn-save-sensors", "n_clicks"),
    State("sensor-1", "value"),
    State("sensor-2", "value"),
    State("sensor-3", "value"),
    State("sensor-4", "value"),
    prevent_initial_call=True
)
def save_sensors(n, s1, s2, s3, s4):
    """
    Salva a configuração dos sensores no arquivo config.json
    """
    CONFIG_FILE.parent.mkdir(exist_ok=True)
    config = {}
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r") as f:
            config = json.load(f)

    config["sensors"] = {
        "S1 – Vazão (L/s)": s1 or "Sensor 1",
        "S2 – Vazão (L/s)": s2 or "Sensor 2",
        "S3- Vazão (L/s)": s3 or "Sensor 3",
        "S4 – Vazão (L/s)": s4 or "Sensor 4",
    }

    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=4)
    return "✅ Sensores configurados com sucesso!"


@callback(
    Output("house-preview", "children"),
    Input("upload-house", "contents")
)
def upload_house(contents):
    """
    Atualiza o preview da planta da casa ou salva uma nova imagem
    """
    if contents is None:
        # Mantém o preview atual
        if HOUSE_IMG.exists():
            encoded_image = base64.b64encode(HOUSE_IMG.read_bytes()).decode()
            return html.Img(
                src=f"data:image/png;base64,{encoded_image}",
                style={"maxWidth": "100%", "height": "auto", "border": "1px solid #ccc"}
            )
        return html.Div()

    # Salva a imagem enviada pelo usuário
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    ASSETS_PATH.mkdir(exist_ok=True)
    with open(HOUSE_IMG, 'wb') as f:
        f.write(decoded)

    return html.Img(
        src=f"data:image/png;base64,{content_string}",
        style={"maxWidth": "100%", "height":"auto", "border":"1px solid #ccc"}
    )
