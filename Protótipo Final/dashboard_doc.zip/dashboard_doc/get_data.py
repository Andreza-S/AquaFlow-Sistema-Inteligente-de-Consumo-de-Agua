import serial
import csv
from datetime import datetime

# -----------------------------
# Configuração da porta serial
# -----------------------------
ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)

# Ordem dos sensores conforme o circuito C
sensor_order = [25, 26, 32, 33]

# Buffer temporário para armazenar leituras parciais
buffer = {gpio: None for gpio in sensor_order}

# Caminho do CSV
csv_path = "dashboard/data/data_test.csv"

# Abre CSV para adicionar dados
csv_file = open(csv_path, mode="a", newline="")
writer = csv.writer(csv_file)

# Escreve cabeçalho se CSV vazio
if csv_file.tell() == 0:
    header = ["Timestamp"]
    for i in range(1, len(sensor_order) + 1):
        header += [f"S{i} Pulsos", f"S{i} L/s"]
    writer.writerow(header)
    csv_file.flush()

# -----------------------------
# Loop principal de leitura
# -----------------------------
try:
    while True:
        linha = ser.readline().decode("utf-8", errors="ignore").strip()
        if not linha:
            continue

        # Processa linhas iniciadas por GPIO
        if linha.startswith("GPIO"):
            try:
                partes = [p.strip() for p in linha.split("|")]

                gpio = int(partes[0].replace("GPIO", "").strip())
                pulsos = int(partes[1].replace("Pulsos:", "").strip())
                l_s = float(partes[3].replace("L/s", "").strip())

                # Salva no buffer
                buffer[gpio] = (pulsos, l_s)

                # Quando todos os sensores enviaram dados → grava CSV
                if all(buffer[g] is not None for g in sensor_order):

                    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                    row = [ts]
                    for g in sensor_order:
                        p, ls = buffer[g]
                        row += [p, ls]

                    writer.writerow(row)
                    csv_file.flush()
                    print("Linha adicionada:", row)

                    # Limpa buffer para próxima leitura
                    buffer = {gpio: None for gpio in sensor_order}

            except Exception as e:
                print("Linha ignorada:", linha, "| Erro:", e)

except KeyboardInterrupt:
    # Fechamento seguro
    print("\nEncerrando...")
    csv_file.close()
    ser.close()
    print(f"Arquivo salvo em {csv_path}")
