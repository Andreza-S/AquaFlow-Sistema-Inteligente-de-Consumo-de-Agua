from pathlib import Path
import dash
from dash import html, dcc, Input, Output
import dash_bootstrap_components as dbc

# Importação das páginas do dashboard
import pages.home as home_page
import pages.heatmap as heatmap_page
import pages.consumption as consumption_page
import pages.dataset as dataset_page
import pages.prediction as prediction_page
import pages.alerts as alerts_page

# Diretório base do projeto
BASE_DIR = Path(__file__).parent

# Definição dos caminhos dos arquivos CSV
# data_test.csv → dados coletados em tempo real
# data.csv → dados simulados para testes e previsões
DATA_REAL_PATH = BASE_DIR / 'data' / 'data_test.csv'
DATA_TEST_PATH = BASE_DIR / 'data' / 'data.csv'

# Credenciais básicas (não utilizadas diretamente no código atual)
CREDENTIALS = {'admin': 'password'}

# Inicialização da aplicação Dash
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    suppress_callback_exceptions=True
)

# Servidor utilizado para deploy
server = app.server

# Definição da barra lateral (sidebar) de navegação
sidebar = html.Div([
    html.H2('AquaFlow', className='display-6 p-3'),
    html.Hr(),
    dbc.Nav([
        dbc.NavLink('Home', href='/', active='exact'),
        dbc.NavLink('Mapa de Calor', href='/heatmap', active='exact'),
        dbc.NavLink('Consumo', href='/consumption', active='exact'),
        dbc.NavLink('Previsão', href='/prediction', active='exact'),
        dbc.NavLink('Alertas', href='/alerts', active='exact'),
        dbc.NavLink('Dataset', href='/dataset', active='exact')
    ], vertical=True, pills=True),
], style={
    'width': '250px',
    'position': 'fixed',
    'height': '100%',
    'backgroundColor': '#f8f9fa'
})

# Área principal onde o conteúdo das páginas é exibido
content = html.Div(id='page-content', style={
    'marginLeft': '270px',
    'padding': '20px'
})

# Layout principal da aplicação
app.layout = html.Div([
    dcc.Location(id='url'),
    sidebar,
    content
])

# Registro dos callbacks específicos da página Dataset
# Esses callbacks utilizam os dados coletados em tempo real
dataset_page.register_callbacks(app)

# Callback responsável por controlar a navegação entre páginas
@app.callback(
    Output('page-content', 'children'),
    Input('url', 'pathname')
)
def display_page(pathname):
    """
    Controla a renderização das páginas do dashboard
    com base na rota acessada pelo usuário.
    """

    if pathname == '/' or pathname == '':
        return home_page.layout(DATA_REAL_PATH)

    if pathname == '/dataset':
        return dataset_page.layout(DATA_REAL_PATH)

    if pathname == '/prediction':
        return prediction_page.layout(DATA_TEST_PATH)

    if pathname == '/consumption':
        return consumption_page.layout(DATA_TEST_PATH)

    if pathname == '/heatmap':
        return heatmap_page.layout(DATA_REAL_PATH)

    if pathname == '/alerts':
        return alerts_page.layout(DATA_REAL_PATH)

    return html.H3('404 - Página não encontrada')


# Execução da aplicação
if __name__ == '__main__':
    app.run(debug=True)
