import json
from pathlib import Path
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression

from preprocess import load_and_prepare

MODEL_DIR = Path(__file__).resolve().parent / "models"
MODEL_DIR.mkdir(exist_ok=True)


def evaluate_model(model, X_train, X_test, y_train, y_test):
    model.fit(X_train, y_train)
    preds = model.predict(X_test)

    return {
        "model": model,
        "mae": mean_absolute_error(y_test, preds),
        "mse": mean_squared_error(y_test, preds),
        "rmse": mean_squared_error(y_test, preds) ** 0.5,
        "r2": r2_score(y_test, preds)
    }


def main():
    X, y, monthly = load_and_prepare()

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, shuffle=False
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "LinearRegression": LinearRegression(),
        "DecisionTree": DecisionTreeRegressor(),
        "RandomForest": RandomForestRegressor(n_estimators=200),
        "SVR": SVR(kernel='rbf'),
        "GradientBoosting": GradientBoostingRegressor()
    }

    results = {}
    best_model = None
    best_score = float('-inf')
    best_name = None

    for name, model in models.items():
        print(f"Treinando: {name}")
        res = evaluate_model(model, X_train_scaled, X_test_scaled, y_train, y_test)

        results[name] = {
            "mae": res["mae"],
            "mse": res["mse"],
            "rmse": res["rmse"],
            "r2": res["r2"]
        }

        if res["r2"] > best_score:
            best_score = res["r2"]
            best_model = res["model"]
            best_name = name

    # Salvar resultados
    with open(MODEL_DIR / "results.json", "w") as f:
        json.dump(results, f, indent=4)

    # Salvar melhor modelo + scaler
    pickle.dump(best_model, open(MODEL_DIR / "best_model.pkl", "wb"))
    pickle.dump(scaler, open(MODEL_DIR / "scaler.pkl", "wb"))

    print("\n==== Melhor modelo salvo! ====")
    print("Modelo:", best_name)
    print("R²:", best_score)


if __name__ == "__main__":
    main()