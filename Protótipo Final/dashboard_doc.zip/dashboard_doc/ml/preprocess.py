import pandas as pd
import numpy as np
from pathlib import Path

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "data.csv"

def load_and_prepare():
    df = pd.read_csv(DATA_FILE)

    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    df = df.set_index('Timestamp')

    # Colunas dos sensores
    sensor_cols = [
        'S1 – Vazão (L/s)', 'S2 – Vazão (L/s)',
        'S3- Vazão (L/s)', 'S4 – Vazão (L/s)'
    ]

    # Total em litros a cada 15 min
    df['Total_L'] = df[sensor_cols].sum(axis=1) * 900

    # Total mensal
    monthly = df['Total_L'].resample('ME').sum().reset_index()

    # Cria índice de tempo para regressão
    monthly['month_idx'] = np.arange(len(monthly))

    # ===== ALVO: TOTAL DO PRÓXIMO MÊS =====
    monthly['next_total'] = monthly['Total_L'].shift(-1)

    # Remover último mês, pois não tem rótulo
    monthly = monthly.dropna().reset_index(drop=True)

    # Features e alvo
    X = monthly[['month_idx']]
    y = monthly['next_total']

    return X, y, monthly
